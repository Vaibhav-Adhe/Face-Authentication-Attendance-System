import cv2
import face_recognition
import numpy as np
import os
from datetime import datetime

DATASET_DIR = "faces"
ATT_FILE = "attendance.csv"

known_encodings = []
known_names = []

if not os.path.exists(DATASET_DIR):
    print("No registered faces found.")
    exit()

for file in os.listdir(DATASET_DIR):
    path = os.path.join(DATASET_DIR, file)
    image = face_recognition.load_image_file(path)
    encs = face_recognition.face_encodings(image)
    if encs:
        known_encodings.append(encs[0])
        known_names.append(os.path.splitext(file)[0])

def mark_attendance(name, action):
    with open(ATT_FILE, "a") as f:
        f.write(f"{name},{action},{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

cam = cv2.VideoCapture(0)
if not cam.isOpened():
    print("Camera not accessible")
    exit()

print("Press I = Punch In | O = Punch Out | Q = Quit")

while True:
    ret, frame = cam.read()
    if not ret:
        continue

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    locations = face_recognition.face_locations(rgb)
    encodings = face_recognition.face_encodings(rgb, locations)

    current_name = "Unknown"

    for enc, loc in zip(encodings, locations):
        distances = face_recognition.face_distance(known_encodings, enc)
        if len(distances) > 0 and np.min(distances) < 0.5:
            idx = np.argmin(distances)
            current_name = known_names[idx]

        top, right, bottom, left = loc
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.putText(frame, current_name, (left, top - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    cv2.putText(frame, "I:PunchIn  O:PunchOut  Q:Quit",
                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

    cv2.imshow("Face Attendance System", frame)
    key = cv2.waitKey(1) & 0xFF

    if key == ord('i') and current_name != "Unknown":
        mark_attendance(current_name, "Punch-In")
        print("Punch-In marked")

    elif key == ord('o') and current_name != "Unknown":
        mark_attendance(current_name, "Punch-Out")
        print("Punch-Out marked")

    elif key == ord('q'):
        break

cam.release()
cv2.destroyAllWindows()
