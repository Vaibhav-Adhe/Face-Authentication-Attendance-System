Face Authentication Attendance System (Stable Version)

Requirements:
Python 3.8+
Webcam

Install:
pip install opencv-python face-recognition numpy pillow

Run:
1) python register_face.py
2) python recognize_attendance.py

Keys:
I - Punch In
O - Punch Out
Q - Quit

Notes:
- Works with real camera
- Handles lighting variation
- CSV-based attendance
