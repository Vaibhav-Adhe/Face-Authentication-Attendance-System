import cv2
import os

def main():
    name = input("Enter user name: ").strip()
    if not name:
        print("Invalid name")
        return

    os.makedirs("faces", exist_ok=True)
    save_path = f"faces/{name}.jpg"

    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        print("Camera not accessible")
        return

    print("Press 's' to save face, 'q' to quit")

    while True:
        ret, frame = cam.read()
        if not ret:
            continue

        cv2.imshow("Register Face", frame)
        key = cv2.waitKey(1) & 0xFF

        if key == ord('s'):
            cv2.imwrite(save_path, frame)
            print("Face registered successfully")
            break
        elif key == ord('q'):
            break

    cam.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
